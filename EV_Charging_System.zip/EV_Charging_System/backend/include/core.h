#ifndef CORE_H
#define CORE_H

#include "types.h"
#include <time.h>

typedef struct QueueNode {
    int booking_id;
    int user_id;
    int station_id;
    time_t request_time;
    struct QueueNode *next;
} QueueNode;

typedef struct {
    QueueNode *front;
    QueueNode *rear;
    int count;
} BookingQueue;

void core_init(void);

// Authentication
int auth_register(const char *username, const char *password, const char *full_name, const char *mobile, char *err_msg);
int auth_login(const char *username, const char *password, char *session_token, User *out_user, char *err_msg);
int auth_verify_session(const char *session_token, User *out_user);
int auth_logout(const char *session_token);
int auth_change_password(int user_id, const char *old_pwd, const char *new_pwd, char *err_msg);

// Vehicles
int vehicle_add(int user_id, const char *reg_number, const char *model, VehicleType type, ConnectorType conn_type, double battery_kwh, char *err_msg);
int vehicle_list_user(int user_id, Vehicle out_vehicles[], int *count);
int vehicle_get_by_id(int vehicle_id, Vehicle *out_vehicle);
int vehicle_delete(int user_id, int vehicle_id, char *err_msg);

// Stations
int station_list(Station out_stations[], int *count);
int station_get_by_id(int station_id, Station *out_station);
int station_add(const char *name, const char *location, double rate, int total_ports, int avg_duration_mins, double max_power_kw, char *err_msg);
int station_update(int station_id, const char *name, const char *location, double rate, int is_active, double max_power_kw, char *err_msg);

// Bookings & FIFO Queue
int booking_create(int user_id, int vehicle_id, int station_id, int duration_mins, Booking *out_booking, char *err_msg);
int booking_list_user(int user_id, Booking out_bookings[], int *count);
int booking_list_all(Booking out_bookings[], int *count);
int booking_cancel(int user_id, int booking_id, int is_admin, char *err_msg);
int booking_start_charging(int booking_id, char *err_msg);
int booking_complete_charging(int booking_id, double energy_kwh, char *err_msg);

void queue_recalculate_station(int station_id);
int calculate_estimated_wait_time(int station_id, int queue_position);

// FEATURE 1: Smart Charging Recommendation Engine
int recommend_stations_for_vehicle(int vehicle_id, double user_lat, double user_lon, StationRecommendation out_recs[], int *count);

// FEATURE 4: Dynamic Load Balancing
void load_balancer_recalculate_station(int station_id);

// Admin Operational Statistics (Preserved Admin Functions)
void admin_get_stats(AdminStats *stats);

#endif
