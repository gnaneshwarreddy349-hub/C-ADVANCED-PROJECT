#ifndef STORAGE_H
#define STORAGE_H

#include "types.h"

int storage_init(void);
int storage_load_users(User users[], int *count);
int storage_save_users(const User users[], int count);

int storage_load_vehicles(Vehicle vehicles[], int *count);
int storage_save_vehicles(const Vehicle vehicles[], int count);

int storage_load_stations(Station stations[], int *count);
int storage_save_stations(const Station stations[], int count);

int storage_load_bookings(Booking bookings[], int *count);
int storage_save_bookings(const Booking bookings[], int count);

int storage_reset_data(void);

#endif
