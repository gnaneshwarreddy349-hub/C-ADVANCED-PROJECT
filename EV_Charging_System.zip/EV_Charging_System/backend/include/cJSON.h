﻿#ifndef CJSON_H
#define CJSON_H

#include <stddef.h>

/* cJSON Types: */
#define cJSON_Invalid (0)
#define cJSON_False  (1 << 0)
#define cJSON_True   (1 << 1)
#define cJSON_NULL   (1 << 2)
#define cJSON_Number (1 << 3)
#define cJSON_String (1 << 4)
#define cJSON_Array  (1 << 5)
#define cJSON_Object (1 << 6)
#define cJSON_Raw    (1 << 7)

typedef struct cJSON {
    struct cJSON *next;
    struct cJSON *prev;
    struct cJSON *child;
    int type;
    char *valuestring;
    int valueint;
    double valuedouble;
    char *string;
} cJSON;

cJSON *cJSON_CreateObject(void);
cJSON *cJSON_CreateArray(void);
cJSON *cJSON_CreateString(const char *string);
cJSON *cJSON_CreateNumber(double num);
cJSON *cJSON_CreateBool(int boolean);
cJSON *cJSON_CreateNull(void);

void cJSON_AddItemToObject(cJSON *object, const char *string, cJSON *item);
void cJSON_AddItemToArray(cJSON *array, cJSON *item);

void cJSON_AddNullToObject(cJSON * const object, const char * const name);
void cJSON_AddTrueToObject(cJSON * const object, const char * const name);
void cJSON_AddFalseToObject(cJSON * const object, const char * const name);
void cJSON_AddBoolToObject(cJSON * const object, const char * const name, const int boolean);
void cJSON_AddNumberToObject(cJSON * const object, const char * const name, const double number);
void cJSON_AddStringToObject(cJSON * const object, const char * const name, const char * const string);

cJSON *cJSON_GetObjectItemCaseSensitive(const cJSON * const object, const char * const string);
int cJSON_IsString(const cJSON * const item);
int cJSON_IsNumber(const cJSON * const item);
int cJSON_IsObject(const cJSON * const item);
int cJSON_IsArray(const cJSON * const item);

char *cJSON_PrintUnformatted(const cJSON *item);
void cJSON_Delete(cJSON *c);
cJSON *cJSON_Parse(const char *value);

#endif
