#ifndef TYPES_H
#define TYPES_H

#include <time.h>
#include <stdint.h>

#define MAX_STR 128
#define MAX_HASH 256
#define MAX_TOKEN 64
#define MAX_PORTS 16
#define MAX_RECORDS 256

typedef enum {
    ROLE_USER = 0,
    ROLE_ADMIN = 1
} UserRole;

typedef enum {
    VEHICLE_2W = 0,
    VEHICLE_3W = 1,
    VEHICLE_4W = 2,
    VEHICLE_HEAVY = 3
} VehicleType;

typedef enum {
    CONN_TYPE2 = 0,
    CONN_CCS2 = 1,
    CONN_CHADEMO = 2,
    CONN_GB_T = 3
} ConnectorType;

typedef enum {
    PORT_AVAILABLE = 0,
    PORT_OCCUPIED = 1,
    PORT_MAINTENANCE = 2
} PortStatus;

typedef enum {
    STATUS_WAITING = 0,
    STATUS_CONFIRMED = 1,
    STATUS_CHARGING = 2,
    STATUS_COMPLETED = 3,
    STATUS_CANCELLED = 4
} BookingStatus;

typedef struct {
    int id;
    char username[MAX_STR];
    char password_hash[MAX_HASH];
    char salt[MAX_STR];
    char full_name[MAX_STR];
    char mobile[32];
    UserRole role;
    int must_change_password;
    time_t created_at;
} User;

typedef struct {
    int id;
    int user_id;
    char reg_number[32];
    char model[MAX_STR];
    VehicleType vehicle_type;
    ConnectorType connector_type; // Compatible connector
    double battery_capacity_kwh;
    time_t created_at;
} Vehicle;

typedef struct {
    int port_number;
    ConnectorType connector;
    PortStatus status;
    int current_booking_id;
    double max_power_kw;       // Port physical power capability (e.g., 22kW, 50kW)
    double allocated_power_kw; // Current dynamically allocated power by load balancer
} ChargingPoint;

typedef struct {
    int id;
    char name[MAX_STR];
    char location[MAX_STR];
    double latitude;
    double longitude;
    double rate_per_kwh;
    int total_ports;
    ChargingPoint ports[MAX_PORTS];
    int is_active;
    int avg_duration_mins;
    double max_grid_power_kw;      // FEATURE 4: Max grid capacity (e.g. 100kW)
    double current_power_draw_kw;  // Sum of active allocated power
    time_t created_at;
} Station;

typedef struct {
    int id;
    char token_code[MAX_TOKEN];
    int user_id;
    int vehicle_id;
    int station_id;
    int port_assigned;
    BookingStatus status;
    int queue_position;
    int estimated_wait_mins;
    int duration_mins;
    time_t scheduled_time;
    time_t start_time;
    time_t end_time;
    double energy_kwh;
    double total_cost;
    time_t created_at;
} Booking;

typedef struct {
    char session_token[MAX_TOKEN];
    int user_id;
    UserRole role;
    time_t expiry;
} Session;

// FEATURE 1: Recommendation Struct
typedef struct {
    int station_id;
    double recommendation_score;
    double estimated_wait_mins;
    double estimated_cost;
    char reason[MAX_STR];
    int compatible_ports_count;
    double distance_km;
} StationRecommendation;

// Administrator Operational Statistics
typedef struct {
    int total_users;
    int total_stations;
    int total_bookings;
    int active_charging;
    int waiting_in_queue;
    double total_revenue;
} AdminStats;

#endif
