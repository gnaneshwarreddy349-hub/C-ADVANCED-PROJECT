#include "../include/core.h"
#include "../include/storage.h"
#include "../include/sha256.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define MAX_SESSIONS 128
static Session g_sessions[MAX_SESSIONS];
static int g_session_count = 0;

static User g_users[MAX_RECORDS];
static int g_user_count = 0;

static Vehicle g_vehicles[MAX_RECORDS];
static int g_vehicle_count = 0;

static Station g_stations[MAX_RECORDS];
static int g_station_count = 0;

static Booking g_bookings[MAX_RECORDS];
static int g_booking_count = 0;

void core_init(void) {
    storage_init();
    storage_load_users(g_users, &g_user_count);
    storage_load_vehicles(g_vehicles, &g_vehicle_count);
    storage_load_stations(g_stations, &g_station_count);
    storage_load_bookings(g_bookings, &g_booking_count);

    for (int i = 0; i < g_station_count; i++) {
        queue_recalculate_station(g_stations[i].id);
        load_balancer_recalculate_station(g_stations[i].id);
    }
}

static int get_next_user_id(void) {
    int max_id = 0;
    for (int i = 0; i < g_user_count; i++) {
        if (g_users[i].id > max_id) max_id = g_users[i].id;
    }
    return max_id + 1;
}

static int get_next_vehicle_id(void) {
    int max_id = 0;
    for (int i = 0; i < g_vehicle_count; i++) {
        if (g_vehicles[i].id > max_id) max_id = g_vehicles[i].id;
    }
    return max_id + 1;
}

static int get_next_station_id(void) {
    int max_id = 0;
    for (int i = 0; i < g_station_count; i++) {
        if (g_stations[i].id > max_id) max_id = g_stations[i].id;
    }
    return max_id + 1;
}

static int get_next_booking_id(void) {
    int max_id = 0;
    for (int i = 0; i < g_booking_count; i++) {
        if (g_bookings[i].id > max_id) max_id = g_bookings[i].id;
    }
    return max_id + 1;
}

// -------------------------------------------------------------
// USER & AUTHENTICATION
// -------------------------------------------------------------
int auth_register(const char *username, const char *password, const char *full_name, const char *mobile, char *err_msg) {
    if (!username || strlen(username) < 3) {
        strcpy(err_msg, "Username must be at least 3 characters.");
        return 0;
    }
    if (!password || strlen(password) < 6) {
        strcpy(err_msg, "Password must be at least 6 characters.");
        return 0;
    }
    for (int i = 0; i < g_user_count; i++) {
        if (_stricmp(g_users[i].username, username) == 0) {
            strcpy(err_msg, "Username already taken.");
            return 0;
        }
    }
    if (g_user_count >= MAX_RECORDS) {
        strcpy(err_msg, "Maximum user capacity reached.");
        return 0;
    }

    User *nu = &g_users[g_user_count];
    memset(nu, 0, sizeof(User));
    nu->id = get_next_user_id();
    strncpy(nu->username, username, sizeof(nu->username) - 1);
    strncpy(nu->full_name, full_name ? full_name : username, sizeof(nu->full_name) - 1);
    strncpy(nu->mobile, mobile ? mobile : "", sizeof(nu->mobile) - 1);
    nu->role = ROLE_USER;
    nu->must_change_password = 0;
    nu->created_at = time(NULL);

    generate_salt(nu->salt, 16);
    hash_password_sha256(password, nu->salt, nu->password_hash);

    g_user_count++;
    storage_save_users(g_users, g_user_count);
    return 1;
}

int auth_login(const char *username, const char *password, char *session_token, User *out_user, char *err_msg) {
    if (!username || !password) {
        strcpy(err_msg, "Invalid username or password.");
        return 0;
    }
    for (int i = 0; i < g_user_count; i++) {
        if (_stricmp(g_users[i].username, username) == 0) {
            if (verify_password_sha256(password, g_users[i].salt, g_users[i].password_hash)) {
                generate_random_token("SES_", session_token, MAX_TOKEN);
                int s_idx = -1;
                for (int s = 0; s < g_session_count; s++) {
                    if (g_sessions[s].user_id == g_users[i].id) {
                        s_idx = s;
                        break;
                    }
                }
                if (s_idx == -1) {
                    if (g_session_count < MAX_SESSIONS) {
                        s_idx = g_session_count++;
                    } else {
                        s_idx = 0;
                    }
                }
                strncpy(g_sessions[s_idx].session_token, session_token, MAX_TOKEN - 1);
                g_sessions[s_idx].user_id = g_users[i].id;
                g_sessions[s_idx].role = g_users[i].role;
                g_sessions[s_idx].expiry = time(NULL) + (24 * 3600);

                if (out_user) {
                    *out_user = g_users[i];
                }
                return 1;
            } else {
                strcpy(err_msg, "Incorrect password.");
                return 0;
            }
        }
    }
    strcpy(err_msg, "User not found.");
    return 0;
}

int auth_verify_session(const char *session_token, User *out_user) {
    if (!session_token || strlen(session_token) == 0) return 0;
    time_t now = time(NULL);
    for (int i = 0; i < g_session_count; i++) {
        if (strcmp(g_sessions[i].session_token, session_token) == 0) {
            if (g_sessions[i].expiry < now) {
                return 0;
            }
            for (int u = 0; u < g_user_count; u++) {
                if (g_users[u].id == g_sessions[i].user_id) {
                    if (out_user) *out_user = g_users[u];
                    return 1;
                }
            }
        }
    }
    return 0;
}

int auth_logout(const char *session_token) {
    for (int i = 0; i < g_session_count; i++) {
        if (strcmp(g_sessions[i].session_token, session_token) == 0) {
            g_sessions[i].expiry = 0;
            return 1;
        }
    }
    return 0;
}

int auth_change_password(int user_id, const char *old_pwd, const char *new_pwd, char *err_msg) {
    if (!new_pwd || strlen(new_pwd) < 6) {
        strcpy(err_msg, "New password must be at least 6 characters.");
        return 0;
    }
    for (int i = 0; i < g_user_count; i++) {
        if (g_users[i].id == user_id) {
            if (!verify_password_sha256(old_pwd, g_users[i].salt, g_users[i].password_hash)) {
                strcpy(err_msg, "Current password incorrect.");
                return 0;
            }
            generate_salt(g_users[i].salt, 16);
            hash_password_sha256(new_pwd, g_users[i].salt, g_users[i].password_hash);
            g_users[i].must_change_password = 0;
            storage_save_users(g_users, g_user_count);
            return 1;
        }
    }
    strcpy(err_msg, "User not found.");
    return 0;
}

// -------------------------------------------------------------
// VEHICLE MANAGEMENT
// -------------------------------------------------------------
int vehicle_add(int user_id, const char *reg_number, const char *model, VehicleType type, ConnectorType conn_type, double battery_kwh, char *err_msg) {
    if (!reg_number || strlen(reg_number) < 4) {
        strcpy(err_msg, "Invalid vehicle registration number.");
        return 0;
    }
    for (int i = 0; i < g_vehicle_count; i++) {
        if (_stricmp(g_vehicles[i].reg_number, reg_number) == 0) {
            strcpy(err_msg, "Vehicle registration number already exists in system.");
            return 0;
        }
    }
    if (g_vehicle_count >= MAX_RECORDS) {
        strcpy(err_msg, "Vehicle capacity reached.");
        return 0;
    }
    Vehicle *v = &g_vehicles[g_vehicle_count];
    v->id = get_next_vehicle_id();
    v->user_id = user_id;
    strncpy(v->reg_number, reg_number, sizeof(v->reg_number) - 1);
    strncpy(v->model, model ? model : "Electric Vehicle", sizeof(v->model) - 1);
    v->vehicle_type = type;
    v->connector_type = conn_type;
    v->battery_capacity_kwh = battery_kwh > 0 ? battery_kwh : 40.0;
    v->created_at = time(NULL);

    g_vehicle_count++;
    storage_save_vehicles(g_vehicles, g_vehicle_count);
    return 1;
}

int vehicle_list_user(int user_id, Vehicle out_vehicles[], int *count) {
    int c = 0;
    for (int i = 0; i < g_vehicle_count; i++) {
        if (g_vehicles[i].user_id == user_id) {
            out_vehicles[c++] = g_vehicles[i];
        }
    }
    *count = c;
    return 1;
}

int vehicle_get_by_id(int vehicle_id, Vehicle *out_vehicle) {
    for (int i = 0; i < g_vehicle_count; i++) {
        if (g_vehicles[i].id == vehicle_id) {
            *out_vehicle = g_vehicles[i];
            return 1;
        }
    }
    return 0;
}

int vehicle_delete(int user_id, int vehicle_id, char *err_msg) {
    for (int i = 0; i < g_booking_count; i++) {
        if (g_bookings[i].vehicle_id == vehicle_id && 
           (g_bookings[i].status == STATUS_WAITING || g_bookings[i].status == STATUS_CONFIRMED || g_bookings[i].status == STATUS_CHARGING)) {
            strcpy(err_msg, "Cannot delete vehicle with active booking.");
            return 0;
        }
    }
    int found = -1;
    for (int i = 0; i < g_vehicle_count; i++) {
        if (g_vehicles[i].id == vehicle_id && g_vehicles[i].user_id == user_id) {
            found = i;
            break;
        }
    }
    if (found == -1) {
        strcpy(err_msg, "Vehicle not found or unauthorized.");
        return 0;
    }
    for (int i = found; i < g_vehicle_count - 1; i++) {
        g_vehicles[i] = g_vehicles[i + 1];
    }
    g_vehicle_count--;
    storage_save_vehicles(g_vehicles, g_vehicle_count);
    return 1;
}

// -------------------------------------------------------------
// STATIONS & LOAD BALANCING
// -------------------------------------------------------------
int station_list(Station out_stations[], int *count) {
    *count = g_station_count;
    for (int i = 0; i < g_station_count; i++) {
        load_balancer_recalculate_station(g_stations[i].id);
        out_stations[i] = g_stations[i];
    }
    return 1;
}

int station_get_by_id(int station_id, Station *out_station) {
    for (int i = 0; i < g_station_count; i++) {
        if (g_stations[i].id == station_id) {
            load_balancer_recalculate_station(g_stations[i].id);
            *out_station = g_stations[i];
            return 1;
        }
    }
    return 0;
}

int station_add(const char *name, const char *location, double rate, int total_ports, int avg_duration_mins, double max_power_kw, char *err_msg) {
    if (!name || strlen(name) < 2) {
        strcpy(err_msg, "Station name required.");
        return 0;
    }
    if (total_ports <= 0 || total_ports > MAX_PORTS) {
        strcpy(err_msg, "Total ports must be between 1 and 16.");
        return 0;
    }
    if (g_station_count >= MAX_RECORDS) {
        strcpy(err_msg, "Station capacity reached.");
        return 0;
    }
    Station *s = &g_stations[g_station_count];
    memset(s, 0, sizeof(Station));
    s->id = get_next_station_id();
    strncpy(s->name, name, sizeof(s->name) - 1);
    strncpy(s->location, location ? location : "", sizeof(s->location) - 1);
    s->latitude = 17.4400 + ((rand() % 50) / 1000.0);
    s->longitude = 78.3800 + ((rand() % 50) / 1000.0);
    s->rate_per_kwh = rate > 0 ? rate : 15.0;
    s->total_ports = total_ports;
    s->is_active = 1;
    s->avg_duration_mins = avg_duration_mins > 0 ? avg_duration_mins : 45;
    s->max_grid_power_kw = max_power_kw > 0 ? max_power_kw : (total_ports * 30.0);
    s->current_power_draw_kw = 0.0;
    s->created_at = time(NULL);

    for (int p = 0; p < total_ports; p++) {
        s->ports[p].port_number = p + 1;
        s->ports[p].connector = (p % 2 == 0) ? CONN_CCS2 : CONN_TYPE2;
        s->ports[p].status = PORT_AVAILABLE;
        s->ports[p].current_booking_id = 0;
        s->ports[p].max_power_kw = (p % 2 == 0) ? 50.0 : 22.0;
        s->ports[p].allocated_power_kw = 0.0;
    }

    g_station_count++;
    storage_save_stations(g_stations, g_station_count);
    return 1;
}

int station_update(int station_id, const char *name, const char *location, double rate, int is_active, double max_power_kw, char *err_msg) {
    for (int i = 0; i < g_station_count; i++) {
        if (g_stations[i].id == station_id) {
            if (name && strlen(name) > 0) strncpy(g_stations[i].name, name, sizeof(g_stations[i].name) - 1);
            if (location && strlen(location) > 0) strncpy(g_stations[i].location, location, sizeof(g_stations[i].location) - 1);
            if (rate > 0) g_stations[i].rate_per_kwh = rate;
            g_stations[i].is_active = is_active;
            if (max_power_kw > 0) g_stations[i].max_grid_power_kw = max_power_kw;
            load_balancer_recalculate_station(station_id);
            storage_save_stations(g_stations, g_station_count);
            return 1;
        }
    }
    strcpy(err_msg, "Station not found.");
    return 0;
}

// -------------------------------------------------------------
// FEATURE 4: DYNAMIC INTELLIGENT LOAD BALANCING ALGORITHM
// Prevents active charging points from exceeding configured max_grid_power_kw
// -------------------------------------------------------------
void load_balancer_recalculate_station(int station_id) {
    Station *st = NULL;
    for (int s = 0; s < g_station_count; s++) {
        if (g_stations[s].id == station_id) {
            st = &g_stations[s];
            break;
        }
    }
    if (!st) return;

    int active_ports_count = 0;
    for (int p = 0; p < st->total_ports; p++) {
        if (st->ports[p].status == PORT_OCCUPIED && st->ports[p].current_booking_id > 0) {
            for (int b = 0; b < g_booking_count; b++) {
                if (g_bookings[b].id == st->ports[p].current_booking_id && g_bookings[b].status == STATUS_CHARGING) {
                    active_ports_count++;
                    break;
                }
            }
        } else {
            st->ports[p].allocated_power_kw = 0.0;
        }
    }

    if (active_ports_count == 0) {
        st->current_power_draw_kw = 0.0;
        return;
    }

    // Proportional equal-share or max-capability constrained allocation
    double equal_share_kw = st->max_grid_power_kw / active_ports_count;
    double total_allocated = 0.0;

    for (int p = 0; p < st->total_ports; p++) {
        if (st->ports[p].status == PORT_OCCUPIED && st->ports[p].current_booking_id > 0) {
            int is_charging = 0;
            for (int b = 0; b < g_booking_count; b++) {
                if (g_bookings[b].id == st->ports[p].current_booking_id && g_bookings[b].status == STATUS_CHARGING) {
                    is_charging = 1;
                    break;
                }
            }
            if (is_charging) {
                // Cannot exceed port hardware rating or equal capacity share
                double alloc = equal_share_kw;
                if (alloc > st->ports[p].max_power_kw) alloc = st->ports[p].max_power_kw;
                st->ports[p].allocated_power_kw = alloc;
                total_allocated += alloc;
            } else {
                st->ports[p].allocated_power_kw = 0.0;
            }
        }
    }
    st->current_power_draw_kw = total_allocated;
}

// -------------------------------------------------------------
// FIFO QUEUE & WAITING TIME
// -------------------------------------------------------------
int calculate_estimated_wait_time(int station_id, int queue_position) {
    if (queue_position <= 0) return 0;
    Station s;
    if (!station_get_by_id(station_id, &s)) return queue_position * 30;
    int ports = s.total_ports > 0 ? s.total_ports : 1;
    int batches = (queue_position - 1) / ports;
    return (batches + 1) * s.avg_duration_mins;
}

void queue_recalculate_station(int station_id) {
    Station *st = NULL;
    for (int s = 0; s < g_station_count; s++) {
        if (g_stations[s].id == station_id) {
            st = &g_stations[s];
            break;
        }
    }
    if (!st) return;

    for (int p = 0; p < st->total_ports; p++) {
        if (st->ports[p].status != PORT_MAINTENANCE) {
            st->ports[p].status = PORT_AVAILABLE;
            st->ports[p].current_booking_id = 0;
        }
    }

    for (int i = 0; i < g_booking_count; i++) {
        if (g_bookings[i].station_id == station_id && g_bookings[i].status == STATUS_CHARGING) {
            int port_idx = g_bookings[i].port_assigned - 1;
            if (port_idx >= 0 && port_idx < st->total_ports && st->ports[port_idx].status != PORT_MAINTENANCE) {
                st->ports[port_idx].status = PORT_OCCUPIED;
                st->ports[port_idx].current_booking_id = g_bookings[i].id;
            }
        }
    }

    int wait_pos = 1;
    for (int i = 0; i < g_booking_count; i++) {
        if (g_bookings[i].station_id == station_id && 
           (g_bookings[i].status == STATUS_WAITING || g_bookings[i].status == STATUS_CONFIRMED)) {
            
            if (g_bookings[i].status == STATUS_WAITING) {
                int free_port = -1;
                for (int p = 0; p < st->total_ports; p++) {
                    if (st->ports[p].status == PORT_AVAILABLE) {
                        free_port = p + 1;
                        break;
                    }
                }
                if (free_port != -1) {
                    g_bookings[i].status = STATUS_CONFIRMED;
                    g_bookings[i].port_assigned = free_port;
                    g_bookings[i].queue_position = 0;
                    g_bookings[i].estimated_wait_mins = 0;
                    st->ports[free_port - 1].status = PORT_OCCUPIED;
                    st->ports[free_port - 1].current_booking_id = g_bookings[i].id;
                } else {
                    g_bookings[i].queue_position = wait_pos++;
                    g_bookings[i].estimated_wait_mins = calculate_estimated_wait_time(station_id, g_bookings[i].queue_position);
                    g_bookings[i].port_assigned = 0;
                }
            } else if (g_bookings[i].status == STATUS_CONFIRMED) {
                int port_idx = g_bookings[i].port_assigned - 1;
                if (port_idx >= 0 && port_idx < st->total_ports && st->ports[port_idx].status != PORT_MAINTENANCE) {
                    st->ports[port_idx].status = PORT_OCCUPIED;
                    st->ports[port_idx].current_booking_id = g_bookings[i].id;
                }
                g_bookings[i].queue_position = 0;
                g_bookings[i].estimated_wait_mins = 0;
            }
        }
    }
    load_balancer_recalculate_station(station_id);
    storage_save_stations(g_stations, g_station_count);
    storage_save_bookings(g_bookings, g_booking_count);
}

// -------------------------------------------------------------
// BOOKING CREATION & QR TOKEN DISPATCH
// -------------------------------------------------------------
int booking_create(int user_id, int vehicle_id, int station_id, int duration_mins, Booking *out_booking, char *err_msg) {
    for (int i = 0; i < g_booking_count; i++) {
        if (g_bookings[i].user_id == user_id && 
           (g_bookings[i].status == STATUS_WAITING || g_bookings[i].status == STATUS_CONFIRMED || g_bookings[i].status == STATUS_CHARGING)) {
            strcpy(err_msg, "You already have an active charging session or booking.");
            return 0;
        }
    }

    Station st;
    if (!station_get_by_id(station_id, &st)) {
        strcpy(err_msg, "Station does not exist.");
        return 0;
    }
    if (!st.is_active) {
        strcpy(err_msg, "Station is currently inactive/under maintenance.");
        return 0;
    }

    if (g_booking_count >= MAX_RECORDS) {
        strcpy(err_msg, "System booking capacity reached.");
        return 0;
    }

    Booking *b = &g_bookings[g_booking_count];
    memset(b, 0, sizeof(Booking));
    b->id = get_next_booking_id();
    snprintf(b->token_code, sizeof(b->token_code), "EV-TK-%04d-%02X", b->id, (unsigned int)(rand() % 0xFF));

    b->user_id = user_id;
    b->vehicle_id = vehicle_id;
    b->station_id = station_id;
    b->duration_mins = duration_mins > 0 ? duration_mins : st.avg_duration_mins;
    b->status = STATUS_WAITING;
    b->created_at = time(NULL);
    b->scheduled_time = b->created_at;

    g_booking_count++;
    queue_recalculate_station(station_id);

    for (int i = 0; i < g_booking_count; i++) {
        if (g_bookings[i].id == b->id) {
            if (out_booking) *out_booking = g_bookings[i];
            break;
        }
    }
    return 1;
}

int booking_list_user(int user_id, Booking out_bookings[], int *count) {
    int c = 0;
    for (int i = g_booking_count - 1; i >= 0; i--) {
        if (g_bookings[i].user_id == user_id) {
            out_bookings[c++] = g_bookings[i];
        }
    }
    *count = c;
    return 1;
}

int booking_list_all(Booking out_bookings[], int *count) {
    int c = 0;
    for (int i = g_booking_count - 1; i >= 0; i--) {
        out_bookings[c++] = g_bookings[i];
    }
    *count = c;
    return 1;
}

int booking_cancel(int user_id, int booking_id, int is_admin, char *err_msg) {
    for (int i = 0; i < g_booking_count; i++) {
        if (g_bookings[i].id == booking_id) {
            if (!is_admin && g_bookings[i].user_id != user_id) {
                strcpy(err_msg, "Unauthorized to cancel this booking.");
                return 0;
            }
            if (g_bookings[i].status == STATUS_COMPLETED || g_bookings[i].status == STATUS_CANCELLED) {
                strcpy(err_msg, "Booking is already completed or cancelled.");
                return 0;
            }
            g_bookings[i].status = STATUS_CANCELLED;
            g_bookings[i].end_time = time(NULL);
            queue_recalculate_station(g_bookings[i].station_id);
            return 1;
        }
    }
    strcpy(err_msg, "Booking not found.");
    return 0;
}

int booking_start_charging(int booking_id, char *err_msg) {
    for (int i = 0; i < g_booking_count; i++) {
        if (g_bookings[i].id == booking_id) {
            if (g_bookings[i].status != STATUS_CONFIRMED) {
                strcpy(err_msg, "Booking must be confirmed at an assigned port before charging starts.");
                return 0;
            }
            g_bookings[i].status = STATUS_CHARGING;
            g_bookings[i].start_time = time(NULL);
            queue_recalculate_station(g_bookings[i].station_id);
            return 1;
        }
    }
    strcpy(err_msg, "Booking not found.");
    return 0;
}

int booking_complete_charging(int booking_id, double energy_kwh, char *err_msg) {
    for (int i = 0; i < g_booking_count; i++) {
        if (g_bookings[i].id == booking_id) {
            if (g_bookings[i].status != STATUS_CHARGING && g_bookings[i].status != STATUS_CONFIRMED) {
                strcpy(err_msg, "Booking is not currently in charging or confirmed state.");
                return 0;
            }
            g_bookings[i].status = STATUS_COMPLETED;
            g_bookings[i].end_time = time(NULL);
            g_bookings[i].energy_kwh = energy_kwh > 0 ? energy_kwh : 20.0;

            Station st;
            if (station_get_by_id(g_bookings[i].station_id, &st)) {
                g_bookings[i].total_cost = g_bookings[i].energy_kwh * st.rate_per_kwh;
            } else {
                g_bookings[i].total_cost = g_bookings[i].energy_kwh * 15.0;
            }

            queue_recalculate_station(g_bookings[i].station_id);
            return 1;
        }
    }
    strcpy(err_msg, "Booking not found.");
    return 0;
}

// -------------------------------------------------------------
// FEATURE 1: SMART CHARGING RECOMMENDATION ENGINE
// Evaluates: Distance, Tariff, Waiting Time, Port Availability, Connector Compatibility
// -------------------------------------------------------------
static double haversine_km(double lat1, double lon1, double lat2, double lon2) {
    if (lat1 == 0.0 || lon1 == 0.0 || lat2 == 0.0 || lon2 == 0.0) return 3.5; // Default proxy distance
    double dlat = (lat2 - lat1) * 3.14159265 / 180.0;
    double dlon = (lon2 - lon1) * 3.14159265 / 180.0;
    double a = sin(dlat / 2.0) * sin(dlat / 2.0) +
               cos(lat1 * 3.14159265 / 180.0) * cos(lat2 * 3.14159265 / 180.0) *
               sin(dlon / 2.0) * sin(dlon / 2.0);
    double c = 2.0 * atan2(sqrt(a), sqrt(1.0 - a));
    return 6371.0 * c;
}

int recommend_stations_for_vehicle(int vehicle_id, double user_lat, double user_lon, StationRecommendation out_recs[], int *count) {
    Vehicle veh;
    int has_veh = vehicle_get_by_id(vehicle_id, &veh);
    ConnectorType target_conn = has_veh ? veh.connector_type : CONN_CCS2;
    double user_battery = has_veh ? veh.battery_capacity_kwh : 40.0;

    int total_recs = 0;
    for (int s = 0; s < g_station_count; s++) {
        if (!g_stations[s].is_active) continue;

        StationRecommendation *rec = &out_recs[total_recs];
        rec->station_id = g_stations[s].id;

        // Check compatible ports count
        int comp_ports = 0;
        int avail_comp = 0;
        for (int p = 0; p < g_stations[s].total_ports; p++) {
            if (g_stations[s].ports[p].connector == target_conn) {
                comp_ports++;
                if (g_stations[s].ports[p].status == PORT_AVAILABLE) avail_comp++;
            }
        }
        rec->compatible_ports_count = comp_ports;

        // Distance in km
        rec->distance_km = haversine_km(user_lat, user_lon, g_stations[s].latitude, g_stations[s].longitude);

        // Queue waiting time
        int queue_count = 0;
        for (int b = 0; b < g_booking_count; b++) {
            if (g_bookings[b].station_id == g_stations[s].id && g_bookings[b].status == STATUS_WAITING) {
                queue_count++;
            }
        }
        rec->estimated_wait_mins = calculate_estimated_wait_time(g_stations[s].id, queue_count + 1);
        if (avail_comp > 0) rec->estimated_wait_mins = 0;

        // Estimated cost for ~60% standard battery replenish
        double est_energy = user_battery * 0.60;
        rec->estimated_cost = est_energy * g_stations[s].rate_per_kwh;

        // Scoring Formula (0 to 100):
        // 35% weight: Waiting time penalty
        // 25% weight: Distance penalty
        // 20% weight: Tariff efficiency
        // 20% weight: Connector compatibility match
        double wait_score = rec->estimated_wait_mins == 0 ? 35.0 : (35.0 / (1.0 + (rec->estimated_wait_mins / 15.0)));
        double dist_score = 25.0 / (1.0 + (rec->distance_km / 5.0));
        double rate_score = 20.0 * (15.0 / (g_stations[s].rate_per_kwh > 0 ? g_stations[s].rate_per_kwh : 15.0));
        if (rate_score > 20.0) rate_score = 20.0;
        double comp_score = (comp_ports > 0) ? (avail_comp > 0 ? 20.0 : 12.0) : 0.0;

        rec->recommendation_score = wait_score + dist_score + rate_score + comp_score;

        // Primary recommendation reason
        if (avail_comp > 0 && comp_ports > 0) {
            snprintf(rec->reason, sizeof(rec->reason), "Zero waiting time with compatible port available immediately.");
        } else if (comp_ports > 0 && rec->distance_km < 3.0) {
            snprintf(rec->reason, sizeof(rec->reason), "Closest compatible station (%.1f km) with low tariff.", rec->distance_km);
        } else if (g_stations[s].rate_per_kwh <= 16.0) {
            snprintf(rec->reason, sizeof(rec->reason), "Most economical tariff (₹%.2f/kWh) with high-power fast charging.", g_stations[s].rate_per_kwh);
        } else {
            snprintf(rec->reason, sizeof(rec->reason), "Optimal balance of queue speed and power capacity.");
        }

        total_recs++;
    }

    // Sort descending by recommendation_score
    for (int i = 0; i < total_recs - 1; i++) {
        for (int j = i + 1; j < total_recs; j++) {
            if (out_recs[j].recommendation_score > out_recs[i].recommendation_score) {
                StationRecommendation temp = out_recs[i];
                out_recs[i] = out_recs[j];
                out_recs[j] = temp;
            }
        }
    }

    *count = total_recs;
    return 1;
}

// -------------------------------------------------------------
// ADMIN OPERATIONAL METRICS (PRESERVED ADMIN FUNCTIONS)
// -------------------------------------------------------------
void admin_get_stats(AdminStats *stats) {
    memset(stats, 0, sizeof(AdminStats));
    stats->total_users = g_user_count;
    stats->total_stations = g_station_count;
    stats->total_bookings = g_booking_count;

    for (int i = 0; i < g_booking_count; i++) {
        if (g_bookings[i].status == STATUS_CHARGING) {
            stats->active_charging++;
        } else if (g_bookings[i].status == STATUS_WAITING) {
            stats->waiting_in_queue++;
        } else if (g_bookings[i].status == STATUS_COMPLETED) {
            stats->total_revenue += g_bookings[i].total_cost;
        }
    }
}
