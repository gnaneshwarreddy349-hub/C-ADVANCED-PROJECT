#include "../include/core.h"
#include "../include/server.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char *argv[]) {
    srand((unsigned int)time(NULL));
    int port = 8080;
    if (argc > 1) {
        port = atoi(argv[1]);
        if (port <= 0 || port > 65535) port = 8080;
    }

    printf("[INIT] Initializing EV Token Management Core & Persistence...\n");
    core_init();
    printf("[INIT] Core initialized. Starting HTTP Server on port %d...\n", port);

    server_start(port);
    return 0;
}
