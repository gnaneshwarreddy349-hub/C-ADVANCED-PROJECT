#include "../include/storage.h"
#include "../include/sha256.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define DATA_USERS_FILE     "data/users.dat"
#define DATA_VEHICLES_FILE  "data/vehicles.dat"
#define DATA_STATIONS_FILE  "data/stations.dat"
#define DATA_BOOKINGS_FILE  "data/bookings.dat"

static int safe_write(const char *filepath, const void *buffer, size_t elem_size, size_t count) {
    char temp_path[512];
    snprintf(temp_path, sizeof(temp_path), "%s.tmp", filepath);
    FILE *fp = fopen(temp_path, "wb");
    if (!fp) {
        return 0;
    }
    size_t written = 0;
    if (count > 0 && buffer != NULL) {
        written = fwrite(buffer, elem_size, count, fp);
    }
    fflush(fp);
    fclose(fp);
    if (count > 0 && buffer != NULL && written != count) {
        remove(temp_path);
        return 0;
    }
    remove(filepath);
    return rename(temp_path, filepath) == 0;
}

int storage_init(void) {
    FILE *fp = fopen(DATA_USERS_FILE, "rb");
    if (!fp) {
        storage_reset_data();
    } else {
        fclose(fp);
    }
    return 1;
}

int storage_reset_data(void) {
    User admin;
    memset(&admin, 0, sizeof(User));
    admin.id = 1;
    strncpy(admin.username, "Agreddy", sizeof(admin.username) - 1);
    generate_salt(admin.salt, 16);
    hash_password_sha256("Agreddy@123", admin.salt, admin.password_hash);
    strncpy(admin.full_name, "System Administrator", sizeof(admin.full_name) - 1);
    strncpy(admin.mobile, "7207551850", sizeof(admin.mobile) - 1);
    admin.role = ROLE_ADMIN;
    admin.must_change_password = 1;
    admin.created_at = time(NULL);

    storage_save_users(&admin, 1);

    Station stations[3];
    memset(stations, 0, sizeof(stations));

    // Station 1: Cyber Towers
    stations[0].id = 1;
    strncpy(stations[0].name, "Cyber Towers Supercharge Hub", sizeof(stations[0].name) - 1);
    strncpy(stations[0].location, "HITEC City, Hyderabad", sizeof(stations[0].location) - 1);
    stations[0].latitude = 17.4504;
    stations[0].longitude = 78.3808;
    stations[0].rate_per_kwh = 18.50;
    stations[0].total_ports = 4;
    stations[0].is_active = 1;
    stations[0].avg_duration_mins = 45;
    stations[0].max_grid_power_kw = 120.0;
    stations[0].current_power_draw_kw = 0.0;
    stations[0].created_at = time(NULL);
    for (int p = 0; p < 4; p++) {
        stations[0].ports[p].port_number = p + 1;
        stations[0].ports[p].connector = (p % 2 == 0) ? CONN_CCS2 : CONN_TYPE2;
        stations[0].ports[p].status = PORT_AVAILABLE;
        stations[0].ports[p].current_booking_id = 0;
        stations[0].ports[p].max_power_kw = (p % 2 == 0) ? 60.0 : 22.0;
        stations[0].ports[p].allocated_power_kw = 0.0;
    }

    // Station 2: Gachibowli
    stations[1].id = 2;
    strncpy(stations[1].name, "Gachibowli Green Energy Hub", sizeof(stations[1].name) - 1);
    strncpy(stations[1].location, "Financial District, Hyderabad", sizeof(stations[1].location) - 1);
    stations[1].latitude = 17.4401;
    stations[1].longitude = 78.3489;
    stations[1].rate_per_kwh = 16.00;
    stations[1].total_ports = 3;
    stations[1].is_active = 1;
    stations[1].avg_duration_mins = 40;
    stations[1].max_grid_power_kw = 90.0;
    stations[1].current_power_draw_kw = 0.0;
    stations[1].created_at = time(NULL);
    for (int p = 0; p < 3; p++) {
        stations[1].ports[p].port_number = p + 1;
        stations[1].ports[p].connector = CONN_CCS2;
        stations[1].ports[p].status = PORT_AVAILABLE;
        stations[1].ports[p].current_booking_id = 0;
        stations[1].ports[p].max_power_kw = 50.0;
        stations[1].ports[p].allocated_power_kw = 0.0;
    }

    // Station 3: Secunderabad
    stations[2].id = 3;
    strncpy(stations[2].name, "Secunderabad Metro FastCharge", sizeof(stations[2].name) - 1);
    strncpy(stations[2].location, "Station Road, Secunderabad", sizeof(stations[2].location) - 1);
    stations[2].latitude = 17.4399;
    stations[2].longitude = 78.4983;
    stations[2].rate_per_kwh = 15.00;
    stations[2].total_ports = 2;
    stations[2].is_active = 1;
    stations[2].avg_duration_mins = 30;
    stations[2].max_grid_power_kw = 60.0;
    stations[2].current_power_draw_kw = 0.0;
    stations[2].created_at = time(NULL);
    for (int p = 0; p < 2; p++) {
        stations[2].ports[p].port_number = p + 1;
        stations[2].ports[p].connector = CONN_TYPE2;
        stations[2].ports[p].status = PORT_AVAILABLE;
        stations[2].ports[p].current_booking_id = 0;
        stations[2].ports[p].max_power_kw = 22.0;
        stations[2].ports[p].allocated_power_kw = 0.0;
    }

    storage_save_stations(stations, 3);
    storage_save_vehicles(NULL, 0);
    storage_save_bookings(NULL, 0);

    return 1;
}

int storage_load_users(User users[], int *count) {
    *count = 0;
    FILE *fp = fopen(DATA_USERS_FILE, "rb");
    if (!fp) return 0;
    size_t read_cnt = fread(users, sizeof(User), MAX_RECORDS, fp);
    *count = (int)read_cnt;
    fclose(fp);
    return 1;
}

int storage_save_users(const User users[], int count) {
    return safe_write(DATA_USERS_FILE, users, sizeof(User), count);
}

int storage_load_vehicles(Vehicle vehicles[], int *count) {
    *count = 0;
    FILE *fp = fopen(DATA_VEHICLES_FILE, "rb");
    if (!fp) return 0;
    size_t read_cnt = fread(vehicles, sizeof(Vehicle), MAX_RECORDS, fp);
    *count = (int)read_cnt;
    fclose(fp);
    return 1;
}

int storage_save_vehicles(const Vehicle vehicles[], int count) {
    return safe_write(DATA_VEHICLES_FILE, vehicles, sizeof(Vehicle), count);
}

int storage_load_stations(Station stations[], int *count) {
    *count = 0;
    FILE *fp = fopen(DATA_STATIONS_FILE, "rb");
    if (!fp) return 0;
    size_t read_cnt = fread(stations, sizeof(Station), MAX_RECORDS, fp);
    *count = (int)read_cnt;
    fclose(fp);
    return 1;
}

int storage_save_stations(const Station stations[], int count) {
    return safe_write(DATA_STATIONS_FILE, stations, sizeof(Station), count);
}

int storage_load_bookings(Booking bookings[], int *count) {
    *count = 0;
    FILE *fp = fopen(DATA_BOOKINGS_FILE, "rb");
    if (!fp) return 0;
    size_t read_cnt = fread(bookings, sizeof(Booking), MAX_RECORDS, fp);
    *count = (int)read_cnt;
    fclose(fp);
    return 1;
}

int storage_save_bookings(const Booking bookings[], int count) {
    return safe_write(DATA_BOOKINGS_FILE, bookings, sizeof(Booking), count);
}
