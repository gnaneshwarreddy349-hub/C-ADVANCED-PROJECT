#include "../include/server.h"
#include "../include/core.h"
#include "../include/cJSON.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <winsock2.h>
#include <ws2tcpip.h>

#define BUFFER_SIZE 65536

static const char *get_mime_type(const char *path) {
    const char *dot = strrchr(path, '.');
    if (!dot) return "text/plain";
    if (strcmp(dot, ".html") == 0) return "text/html";
    if (strcmp(dot, ".css") == 0) return "text/css";
    if (strcmp(dot, ".js") == 0) return "application/javascript";
    if (strcmp(dot, ".json") == 0) return "application/json";
    if (strcmp(dot, ".png") == 0) return "image/png";
    if (strcmp(dot, ".jpg") == 0 || strcmp(dot, ".jpeg") == 0) return "image/jpeg";
    if (strcmp(dot, ".svg") == 0) return "image/svg+xml";
    if (strcmp(dot, ".ico") == 0) return "image/x-icon";
    return "text/plain";
}

static void send_response(SOCKET client, int status_code, const char *status_text, const char *content_type, const char *body, int body_len) {
    char header[1024];
    snprintf(header, sizeof(header),
        "HTTP/1.1 %d %s\r\n"
        "Content-Type: %s; charset=utf-8\r\n"
        "Content-Length: %d\r\n"
        "Access-Control-Allow-Origin: *\r\n"
        "Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS\r\n"
        "Access-Control-Allow-Headers: Content-Type, Authorization\r\n"
        "Cache-Control: no-store, no-cache, must-revalidate, max-age=0\r\n"
        "Pragma: no-cache\r\n"
        "Connection: close\r\n\r\n",
        status_code, status_text, content_type, body_len);

    send(client, header, (int)strlen(header), 0);
    if (body && body_len > 0) {
        send(client, body, body_len, 0);
    }
}

static void send_json(SOCKET client, int status_code, cJSON *json) {
    char *str = cJSON_PrintUnformatted(json);
    if (str) {
        send_response(client, status_code, status_code == 200 ? "OK" : (status_code == 400 ? "Bad Request" : (status_code == 401 ? "Unauthorized" : (status_code == 403 ? "Forbidden" : (status_code == 404 ? "Not Found" : "Internal Server Error")))), "application/json", str, (int)strlen(str));
        free(str);
    } else {
        const char *fallback = "{\"error\":\"json serialization failed\"}";
        send_response(client, 500, "Internal Server Error", "application/json", fallback, (int)strlen(fallback));
    }
    cJSON_Delete(json);
}

static void send_error(SOCKET client, int status_code, const char *message) {
    cJSON *resp = cJSON_CreateObject();
    cJSON_AddBoolToObject(resp, "success", 0);
    cJSON_AddStringToObject(resp, "error", message ? message : "Error");
    send_json(client, status_code, resp);
}

static void serve_static_file(SOCKET client, const char *url_path) {
    char local_path[512];
    if (strcmp(url_path, "/") == 0 || strcmp(url_path, "/index.html") == 0) {
        snprintf(local_path, sizeof(local_path), "frontend/index.html");
    } else {
        snprintf(local_path, sizeof(local_path), "frontend%s", url_path);
    }

    if (strstr(local_path, "..")) {
        send_error(client, 403, "Access denied");
        return;
    }

    FILE *fp = fopen(local_path, "rb");
    if (!fp) {
        send_error(client, 404, "File not found");
        return;
    }

    fseek(fp, 0, SEEK_END);
    long fsize = ftell(fp);
    fseek(fp, 0, SEEK_SET);

    char *buf = (char*)malloc(fsize);
    if (!buf) {
        fclose(fp);
        send_error(client, 500, "Out of memory");
        return;
    }

    size_t read_bytes = fread(buf, 1, fsize, fp);
    fclose(fp);

    const char *mime = get_mime_type(local_path);
    send_response(client, 200, "OK", mime, buf, (int)read_bytes);
    free(buf);
}

static void get_auth_token_from_header(const char *headers, char *token_out, size_t max_len) {
    token_out[0] = '\0';
    const char *auth = strstr(headers, "Authorization: Bearer ");
    if (auth) {
        auth += 22;
        const char *end = strstr(auth, "\r\n");
        if (!end) end = strchr(auth, '\n');
        size_t len = end ? (size_t)(end - auth) : strlen(auth);
        if (len >= max_len) len = max_len - 1;
        strncpy(token_out, auth, len);
        token_out[len] = '\0';
    }
}

static void handle_api_request(SOCKET client, const char *method, const char *path, const char *headers, const char *body) {
    char auth_token[128];
    get_auth_token_from_header(headers, auth_token, sizeof(auth_token));
    User cur_user;
    int is_authenticated = auth_verify_session(auth_token, &cur_user);

    // Authentication Endpoints
    if (strcmp(path, "/api/auth/register") == 0 && strcmp(method, "POST") == 0) {
        cJSON *root = cJSON_Parse(body);
        if (!root) { send_error(client, 400, "Invalid JSON"); return; }
        cJSON *u = cJSON_GetObjectItemCaseSensitive(root, "username");
        cJSON *p = cJSON_GetObjectItemCaseSensitive(root, "password");
        cJSON *fn = cJSON_GetObjectItemCaseSensitive(root, "full_name");
        cJSON *mb = cJSON_GetObjectItemCaseSensitive(root, "mobile");
        char err[128] = {0};
        if (!auth_register(u ? u->valuestring : NULL, p ? p->valuestring : NULL, fn ? fn->valuestring : NULL, mb ? mb->valuestring : NULL, err)) {
            cJSON_Delete(root);
            send_error(client, 400, err);
            return;
        }
        cJSON_Delete(root);
        cJSON *resp = cJSON_CreateObject();
        cJSON_AddBoolToObject(resp, "success", 1);
        cJSON_AddStringToObject(resp, "message", "User registered successfully");
        send_json(client, 200, resp);
        return;
    }

    if (strcmp(path, "/api/auth/login") == 0 && strcmp(method, "POST") == 0) {
        cJSON *root = cJSON_Parse(body);
        if (!root) { send_error(client, 400, "Invalid JSON"); return; }
        cJSON *u = cJSON_GetObjectItemCaseSensitive(root, "username");
        cJSON *p = cJSON_GetObjectItemCaseSensitive(root, "password");
        char token[64] = {0};
        char err[128] = {0};
        User user;
        if (!auth_login(u ? u->valuestring : NULL, p ? p->valuestring : NULL, token, &user, err)) {
            cJSON_Delete(root);
            send_error(client, 401, err);
            return;
        }
        cJSON_Delete(root);
        cJSON *resp = cJSON_CreateObject();
        cJSON_AddBoolToObject(resp, "success", 1);
        cJSON_AddStringToObject(resp, "token", token);
        cJSON *uobj = cJSON_CreateObject();
        cJSON_AddNumberToObject(uobj, "id", user.id);
        cJSON_AddStringToObject(uobj, "username", user.username);
        cJSON_AddStringToObject(uobj, "full_name", user.full_name);
        cJSON_AddStringToObject(uobj, "mobile", user.mobile);
        cJSON_AddNumberToObject(uobj, "role", user.role);
        cJSON_AddBoolToObject(uobj, "must_change_password", user.must_change_password);
        cJSON_AddItemToObject(resp, "user", uobj);
        send_json(client, 200, resp);
        return;
    }

    if (strcmp(path, "/api/auth/logout") == 0 && strcmp(method, "POST") == 0) {
        auth_logout(auth_token);
        cJSON *resp = cJSON_CreateObject();
        cJSON_AddBoolToObject(resp, "success", 1);
        cJSON_AddStringToObject(resp, "message", "Logged out");
        send_json(client, 200, resp);
        return;
    }

    if (strcmp(path, "/api/auth/me") == 0 && strcmp(method, "GET") == 0) {
        if (!is_authenticated) { send_error(client, 401, "Unauthorized"); return; }
        cJSON *resp = cJSON_CreateObject();
        cJSON_AddBoolToObject(resp, "success", 1);
        cJSON *uobj = cJSON_CreateObject();
        cJSON_AddNumberToObject(uobj, "id", cur_user.id);
        cJSON_AddStringToObject(uobj, "username", cur_user.username);
        cJSON_AddStringToObject(uobj, "full_name", cur_user.full_name);
        cJSON_AddStringToObject(uobj, "mobile", cur_user.mobile);
        cJSON_AddNumberToObject(uobj, "role", cur_user.role);
        cJSON_AddBoolToObject(uobj, "must_change_password", cur_user.must_change_password);
        cJSON_AddItemToObject(resp, "user", uobj);
        send_json(client, 200, resp);
        return;
    }

    // Stations Endpoints (Includes Feature 4 Load Balancing)
    if (strcmp(path, "/api/stations") == 0 && strcmp(method, "GET") == 0) {
        Station stations[MAX_RECORDS];
        int count = 0;
        station_list(stations, &count);
        cJSON *resp = cJSON_CreateObject();
        cJSON_AddBoolToObject(resp, "success", 1);
        cJSON *arr = cJSON_CreateArray();
        for (int i = 0; i < count; i++) {
            cJSON *s = cJSON_CreateObject();
            cJSON_AddNumberToObject(s, "id", stations[i].id);
            cJSON_AddStringToObject(s, "name", stations[i].name);
            cJSON_AddStringToObject(s, "location", stations[i].location);
            cJSON_AddNumberToObject(s, "latitude", stations[i].latitude);
            cJSON_AddNumberToObject(s, "longitude", stations[i].longitude);
            cJSON_AddNumberToObject(s, "rate_per_kwh", stations[i].rate_per_kwh);
            cJSON_AddNumberToObject(s, "total_ports", stations[i].total_ports);
            cJSON_AddBoolToObject(s, "is_active", stations[i].is_active);
            cJSON_AddNumberToObject(s, "avg_duration_mins", stations[i].avg_duration_mins);
            cJSON_AddNumberToObject(s, "max_grid_power_kw", stations[i].max_grid_power_kw);
            cJSON_AddNumberToObject(s, "current_power_draw_kw", stations[i].current_power_draw_kw);

            int avail = 0, occ = 0, maint = 0;
            cJSON *ports_arr = cJSON_CreateArray();
            for (int p = 0; p < stations[i].total_ports; p++) {
                cJSON *pt = cJSON_CreateObject();
                cJSON_AddNumberToObject(pt, "port_number", stations[i].ports[p].port_number);
                cJSON_AddNumberToObject(pt, "connector", stations[i].ports[p].connector);
                cJSON_AddNumberToObject(pt, "status", stations[i].ports[p].status);
                cJSON_AddNumberToObject(pt, "current_booking_id", stations[i].ports[p].current_booking_id);
                cJSON_AddNumberToObject(pt, "max_power_kw", stations[i].ports[p].max_power_kw);
                cJSON_AddNumberToObject(pt, "allocated_power_kw", stations[i].ports[p].allocated_power_kw);
                cJSON_AddItemToArray(ports_arr, pt);
                if (stations[i].ports[p].status == PORT_AVAILABLE) avail++;
                else if (stations[i].ports[p].status == PORT_OCCUPIED) occ++;
                else if (stations[i].ports[p].status == PORT_MAINTENANCE) maint++;
            }
            cJSON_AddItemToObject(s, "ports", ports_arr);
            cJSON_AddNumberToObject(s, "available_ports", avail);
            cJSON_AddNumberToObject(s, "occupied_ports", occ);
            cJSON_AddNumberToObject(s, "maintenance_ports", maint);
            cJSON_AddItemToArray(arr, s);
        }
        cJSON_AddItemToObject(resp, "stations", arr);
        send_json(client, 200, resp);
        return;
    }

    if (strcmp(path, "/api/stations") == 0 && strcmp(method, "POST") == 0) {
        if (!is_authenticated || cur_user.role != ROLE_ADMIN) { send_error(client, 403, "Admin authorization required"); return; }
        cJSON *root = cJSON_Parse(body);
        if (!root) { send_error(client, 400, "Invalid JSON"); return; }
        cJSON *n = cJSON_GetObjectItemCaseSensitive(root, "name");
        cJSON *loc = cJSON_GetObjectItemCaseSensitive(root, "location");
        cJSON *rt = cJSON_GetObjectItemCaseSensitive(root, "rate_per_kwh");
        cJSON *tp = cJSON_GetObjectItemCaseSensitive(root, "total_ports");
        cJSON *dur = cJSON_GetObjectItemCaseSensitive(root, "avg_duration_mins");
        cJSON *mp = cJSON_GetObjectItemCaseSensitive(root, "max_grid_power_kw");
        char err[128] = {0};
        if (!station_add(n ? n->valuestring : NULL, loc ? loc->valuestring : NULL, rt ? rt->valuedouble : 15.0, tp ? tp->valueint : 4, dur ? dur->valueint : 45, mp ? mp->valuedouble : 100.0, err)) {
            cJSON_Delete(root);
            send_error(client, 400, err);
            return;
        }
        cJSON_Delete(root);
        cJSON *resp = cJSON_CreateObject();
        cJSON_AddBoolToObject(resp, "success", 1);
        cJSON_AddStringToObject(resp, "message", "Station added successfully");
        send_json(client, 200, resp);
        return;
    }

    if (strncmp(path, "/api/stations/update", 20) == 0 && strcmp(method, "POST") == 0) {
        if (!is_authenticated || cur_user.role != ROLE_ADMIN) { send_error(client, 403, "Admin authorization required"); return; }
        cJSON *root = cJSON_Parse(body);
        if (!root) { send_error(client, 400, "Invalid JSON"); return; }
        cJSON *id = cJSON_GetObjectItemCaseSensitive(root, "id");
        cJSON *n = cJSON_GetObjectItemCaseSensitive(root, "name");
        cJSON *loc = cJSON_GetObjectItemCaseSensitive(root, "location");
        cJSON *rt = cJSON_GetObjectItemCaseSensitive(root, "rate_per_kwh");
        cJSON *act = cJSON_GetObjectItemCaseSensitive(root, "is_active");
        cJSON *mp = cJSON_GetObjectItemCaseSensitive(root, "max_grid_power_kw");
        char err[128] = {0};
        if (!id || !station_update(id->valueint, n ? n->valuestring : NULL, loc ? loc->valuestring : NULL, rt ? rt->valuedouble : 0, act ? act->valueint : 1, mp ? mp->valuedouble : 0, err)) {
            cJSON_Delete(root);
            send_error(client, 400, err[0] ? err : "Missing station id");
            return;
        }
        cJSON_Delete(root);
        cJSON *resp = cJSON_CreateObject();
        cJSON_AddBoolToObject(resp, "success", 1);
        cJSON_AddStringToObject(resp, "message", "Station updated successfully");
        send_json(client, 200, resp);
        return;
    }

    // FEATURE 1: Recommendations Endpoint
    if (strcmp(path, "/api/recommendations") == 0 && strcmp(method, "POST") == 0) {
        cJSON *root = cJSON_Parse(body);
        int veh_id = 0;
        double ulat = 17.4480, ulon = 78.3750; // Default User Location proxy
        if (root) {
            cJSON *vid = cJSON_GetObjectItemCaseSensitive(root, "vehicle_id");
            cJSON *lt = cJSON_GetObjectItemCaseSensitive(root, "latitude");
            cJSON *ln = cJSON_GetObjectItemCaseSensitive(root, "longitude");
            if (vid) veh_id = vid->valueint;
            if (lt) ulat = lt->valuedouble;
            if (ln) ulon = ln->valuedouble;
            cJSON_Delete(root);
        }

        StationRecommendation recs[MAX_RECORDS];
        int count = 0;
        recommend_stations_for_vehicle(veh_id, ulat, ulon, recs, &count);

        cJSON *resp = cJSON_CreateObject();
        cJSON_AddBoolToObject(resp, "success", 1);
        cJSON *arr = cJSON_CreateArray();
        for (int i = 0; i < count; i++) {
            cJSON *r = cJSON_CreateObject();
            cJSON_AddNumberToObject(r, "station_id", recs[i].station_id);
            cJSON_AddNumberToObject(r, "score", recs[i].recommendation_score);
            cJSON_AddNumberToObject(r, "wait_mins", recs[i].estimated_wait_mins);
            cJSON_AddNumberToObject(r, "cost", recs[i].estimated_cost);
            cJSON_AddNumberToObject(r, "distance_km", recs[i].distance_km);
            cJSON_AddNumberToObject(r, "compatible_ports", recs[i].compatible_ports_count);
            cJSON_AddStringToObject(r, "reason", recs[i].reason);

            Station st;
            if (station_get_by_id(recs[i].station_id, &st)) {
                cJSON_AddStringToObject(r, "name", st.name);
                cJSON_AddStringToObject(r, "location", st.location);
                cJSON_AddNumberToObject(r, "rate_per_kwh", st.rate_per_kwh);
            }
            cJSON_AddItemToArray(arr, r);
        }
        cJSON_AddItemToObject(resp, "recommendations", arr);
        send_json(client, 200, resp);
        return;
    }

    // Vehicles Endpoints
    if (strcmp(path, "/api/vehicles") == 0 && strcmp(method, "GET") == 0) {
        if (!is_authenticated) { send_error(client, 401, "Unauthorized"); return; }
        Vehicle vlist[MAX_RECORDS];
        int count = 0;
        vehicle_list_user(cur_user.id, vlist, &count);
        cJSON *resp = cJSON_CreateObject();
        cJSON_AddBoolToObject(resp, "success", 1);
        cJSON *arr = cJSON_CreateArray();
        for (int i = 0; i < count; i++) {
            cJSON *v = cJSON_CreateObject();
            cJSON_AddNumberToObject(v, "id", vlist[i].id);
            cJSON_AddStringToObject(v, "reg_number", vlist[i].reg_number);
            cJSON_AddStringToObject(v, "model", vlist[i].model);
            cJSON_AddNumberToObject(v, "vehicle_type", vlist[i].vehicle_type);
            cJSON_AddNumberToObject(v, "connector_type", vlist[i].connector_type);
            cJSON_AddNumberToObject(v, "battery_capacity_kwh", vlist[i].battery_capacity_kwh);
            cJSON_AddItemToArray(arr, v);
        }
        cJSON_AddItemToObject(resp, "vehicles", arr);
        send_json(client, 200, resp);
        return;
    }

    if (strcmp(path, "/api/vehicles") == 0 && strcmp(method, "POST") == 0) {
        if (!is_authenticated) { send_error(client, 401, "Unauthorized"); return; }
        cJSON *root = cJSON_Parse(body);
        if (!root) { send_error(client, 400, "Invalid JSON"); return; }
        cJSON *reg = cJSON_GetObjectItemCaseSensitive(root, "reg_number");
        cJSON *mod = cJSON_GetObjectItemCaseSensitive(root, "model");
        cJSON *vt = cJSON_GetObjectItemCaseSensitive(root, "vehicle_type");
        cJSON *ct = cJSON_GetObjectItemCaseSensitive(root, "connector_type");
        cJSON *bkwh = cJSON_GetObjectItemCaseSensitive(root, "battery_capacity_kwh");
        char err[128] = {0};
        if (!vehicle_add(cur_user.id, reg ? reg->valuestring : NULL, mod ? mod->valuestring : NULL, vt ? vt->valueint : VEHICLE_4W, ct ? ct->valueint : CONN_CCS2, bkwh ? bkwh->valuedouble : 40.0, err)) {
            cJSON_Delete(root);
            send_error(client, 400, err);
            return;
        }
        cJSON_Delete(root);
        cJSON *resp = cJSON_CreateObject();
        cJSON_AddBoolToObject(resp, "success", 1);
        cJSON_AddStringToObject(resp, "message", "Vehicle added successfully");
        send_json(client, 200, resp);
        return;
    }

    if (strncmp(path, "/api/vehicles/delete", 20) == 0 && strcmp(method, "POST") == 0) {
        if (!is_authenticated) { send_error(client, 401, "Unauthorized"); return; }
        cJSON *root = cJSON_Parse(body);
        if (!root) { send_error(client, 400, "Invalid JSON"); return; }
        cJSON *id = cJSON_GetObjectItemCaseSensitive(root, "id");
        char err[128] = {0};
        if (!id || !vehicle_delete(cur_user.id, id->valueint, err)) {
            cJSON_Delete(root);
            send_error(client, 400, err[0] ? err : "Missing vehicle id");
            return;
        }
        cJSON_Delete(root);
        cJSON *resp = cJSON_CreateObject();
        cJSON_AddBoolToObject(resp, "success", 1);
        cJSON_AddStringToObject(resp, "message", "Vehicle deleted successfully");
        send_json(client, 200, resp);
        return;
    }

    // Bookings & Queue Endpoints
    if (strcmp(path, "/api/bookings") == 0 && strcmp(method, "POST") == 0) {
        if (!is_authenticated) { send_error(client, 401, "Unauthorized"); return; }
        cJSON *root = cJSON_Parse(body);
        if (!root) { send_error(client, 400, "Invalid JSON"); return; }
        cJSON *vid = cJSON_GetObjectItemCaseSensitive(root, "vehicle_id");
        cJSON *sid = cJSON_GetObjectItemCaseSensitive(root, "station_id");
        cJSON *dur = cJSON_GetObjectItemCaseSensitive(root, "duration_mins");
        Booking b;
        char err[128] = {0};
        if (!booking_create(cur_user.id, vid ? vid->valueint : 0, sid ? sid->valueint : 0, dur ? dur->valueint : 30, &b, err)) {
            cJSON_Delete(root);
            send_error(client, 400, err);
            return;
        }
        cJSON_Delete(root);
        cJSON *resp = cJSON_CreateObject();
        cJSON_AddBoolToObject(resp, "success", 1);
        cJSON_AddStringToObject(resp, "message", "Booking processed successfully");
        cJSON *bobj = cJSON_CreateObject();
        cJSON_AddNumberToObject(bobj, "id", b.id);
        cJSON_AddStringToObject(bobj, "token_code", b.token_code);
        cJSON_AddNumberToObject(bobj, "status", b.status);
        cJSON_AddNumberToObject(bobj, "port_assigned", b.port_assigned);
        cJSON_AddNumberToObject(bobj, "queue_position", b.queue_position);
        cJSON_AddNumberToObject(bobj, "estimated_wait_mins", b.estimated_wait_mins);
        cJSON_AddItemToObject(resp, "booking", bobj);
        send_json(client, 200, resp);
        return;
    }

    if (strcmp(path, "/api/bookings") == 0 && strcmp(method, "GET") == 0) {
        if (!is_authenticated) { send_error(client, 401, "Unauthorized"); return; }
        Booking blist[MAX_RECORDS];
        int count = 0;
        if (cur_user.role == ROLE_ADMIN) {
            booking_list_all(blist, &count);
        } else {
            booking_list_user(cur_user.id, blist, &count);
        }
        cJSON *resp = cJSON_CreateObject();
        cJSON_AddBoolToObject(resp, "success", 1);
        cJSON *arr = cJSON_CreateArray();
        for (int i = 0; i < count; i++) {
            cJSON *b = cJSON_CreateObject();
            cJSON_AddNumberToObject(b, "id", blist[i].id);
            cJSON_AddStringToObject(b, "token_code", blist[i].token_code);
            cJSON_AddNumberToObject(b, "user_id", blist[i].user_id);
            cJSON_AddNumberToObject(b, "vehicle_id", blist[i].vehicle_id);
            cJSON_AddNumberToObject(b, "station_id", blist[i].station_id);
            cJSON_AddNumberToObject(b, "port_assigned", blist[i].port_assigned);
            cJSON_AddNumberToObject(b, "status", blist[i].status);
            cJSON_AddNumberToObject(b, "queue_position", blist[i].queue_position);
            cJSON_AddNumberToObject(b, "estimated_wait_mins", blist[i].estimated_wait_mins);
            cJSON_AddNumberToObject(b, "duration_mins", blist[i].duration_mins);
            cJSON_AddNumberToObject(b, "energy_kwh", blist[i].energy_kwh);
            cJSON_AddNumberToObject(b, "total_cost", blist[i].total_cost);
            cJSON_AddNumberToObject(b, "created_at", (double)blist[i].created_at);
            cJSON_AddItemToArray(arr, b);
        }
        cJSON_AddItemToObject(resp, "bookings", arr);
        send_json(client, 200, resp);
        return;
    }

    if (strcmp(path, "/api/bookings/cancel") == 0 && strcmp(method, "POST") == 0) {
        if (!is_authenticated) { send_error(client, 401, "Unauthorized"); return; }
        cJSON *root = cJSON_Parse(body);
        if (!root) { send_error(client, 400, "Invalid JSON"); return; }
        cJSON *id = cJSON_GetObjectItemCaseSensitive(root, "id");
        char err[128] = {0};
        if (!id || !booking_cancel(cur_user.id, id->valueint, cur_user.role == ROLE_ADMIN, err)) {
            cJSON_Delete(root);
            send_error(client, 400, err[0] ? err : "Missing booking id");
            return;
        }
        cJSON_Delete(root);
        cJSON *resp = cJSON_CreateObject();
        cJSON_AddBoolToObject(resp, "success", 1);
        cJSON_AddStringToObject(resp, "message", "Booking cancelled successfully");
        send_json(client, 200, resp);
        return;
    }

    if (strcmp(path, "/api/bookings/start-charging") == 0 && strcmp(method, "POST") == 0) {
        if (!is_authenticated) { send_error(client, 401, "Unauthorized"); return; }
        cJSON *root = cJSON_Parse(body);
        if (!root) { send_error(client, 400, "Invalid JSON"); return; }
        cJSON *id = cJSON_GetObjectItemCaseSensitive(root, "id");
        char err[128] = {0};
        if (!id || !booking_start_charging(id->valueint, err)) {
            cJSON_Delete(root);
            send_error(client, 400, err[0] ? err : "Missing booking id");
            return;
        }
        cJSON_Delete(root);
        cJSON *resp = cJSON_CreateObject();
        cJSON_AddBoolToObject(resp, "success", 1);
        cJSON_AddStringToObject(resp, "message", "Charging started");
        send_json(client, 200, resp);
        return;
    }

    if (strcmp(path, "/api/bookings/complete-charging") == 0 && strcmp(method, "POST") == 0) {
        if (!is_authenticated) { send_error(client, 401, "Unauthorized"); return; }
        cJSON *root = cJSON_Parse(body);
        if (!root) { send_error(client, 400, "Invalid JSON"); return; }
        cJSON *id = cJSON_GetObjectItemCaseSensitive(root, "id");
        cJSON *kwh = cJSON_GetObjectItemCaseSensitive(root, "energy_kwh");
        char err[128] = {0};
        if (!id || !booking_complete_charging(id->valueint, kwh ? kwh->valuedouble : 20.0, err)) {
            cJSON_Delete(root);
            send_error(client, 400, err[0] ? err : "Missing booking id");
            return;
        }
        cJSON_Delete(root);
        cJSON *resp = cJSON_CreateObject();
        cJSON_AddBoolToObject(resp, "success", 1);
        cJSON_AddStringToObject(resp, "message", "Charging completed");
        send_json(client, 200, resp);
        return;
    }

    // Admin Operational Statistics (Preserved Admin Functions)
    if (strcmp(path, "/api/admin/stats") == 0 && strcmp(method, "GET") == 0) {
        if (!is_authenticated || cur_user.role != ROLE_ADMIN) { send_error(client, 403, "Admin authorization required"); return; }
        AdminStats stats;
        admin_get_stats(&stats);
        cJSON *resp = cJSON_CreateObject();
        cJSON_AddBoolToObject(resp, "success", 1);
        cJSON_AddNumberToObject(resp, "total_users", stats.total_users);
        cJSON_AddNumberToObject(resp, "total_stations", stats.total_stations);
        cJSON_AddNumberToObject(resp, "total_bookings", stats.total_bookings);
        cJSON_AddNumberToObject(resp, "active_charging", stats.active_charging);
        cJSON_AddNumberToObject(resp, "waiting_in_queue", stats.waiting_in_queue);
        cJSON_AddNumberToObject(resp, "total_revenue", stats.total_revenue);
        send_json(client, 200, resp);
        return;
    }

    send_error(client, 404, "API endpoint not found");
}

static void handle_client(SOCKET client) {
    char buffer[BUFFER_SIZE];
    int total_bytes = 0;
    while (1) {
        int bytes = recv(client, buffer + total_bytes, sizeof(buffer) - 1 - total_bytes, 0);
        if (bytes <= 0) break;
        total_bytes += bytes;
        buffer[total_bytes] = '\0';
        if (strstr(buffer, "\r\n\r\n") || strstr(buffer, "\n\n")) {
            break;
        }
    }

    if (total_bytes <= 0) {
        closesocket(client);
        return;
    }

    char *hdr_end = strstr(buffer, "\r\n\r\n");
    int delim_len = 4;
    if (!hdr_end) {
        hdr_end = strstr(buffer, "\n\n");
        delim_len = 2;
    }
    int header_len = hdr_end ? (int)(hdr_end - buffer + delim_len) : total_bytes;

    int content_length = 0;
    const char *cl = strstr(buffer, "Content-Length: ");
    if (!cl) cl = strstr(buffer, "content-length: ");
    if (cl) content_length = atoi(cl + 16);

    if (strstr(buffer, "Expect: 100-continue") || strstr(buffer, "expect: 100-continue")) {
        const char *cont = "HTTP/1.1 100 Continue\r\n\r\n";
        send(client, cont, (int)strlen(cont), 0);
    }

    while (total_bytes < header_len + content_length && total_bytes < sizeof(buffer) - 1) {
        int bytes = recv(client, buffer + total_bytes, sizeof(buffer) - 1 - total_bytes, 0);
        if (bytes <= 0) break;
        total_bytes += bytes;
        buffer[total_bytes] = '\0';
    }

    char method[16] = {0};
    char path[256] = {0};
    sscanf(buffer, "%15s %255s", method, path);

    char *q = strchr(path, '?');
    if (q) *q = '\0';

    if (strcmp(method, "OPTIONS") == 0) {
        send_response(client, 200, "OK", "text/plain", "", 0);
        closesocket(client);
        return;
    }

    char *body = strstr(buffer, "\r\n\r\n");
    if (body) {
        body += 4;
    } else {
        body = strstr(buffer, "\n\n");
        if (body) body += 2;
        else body = "";
    }

    if (strncmp(path, "/api/", 5) == 0) {
        handle_api_request(client, method, path, buffer, body);
    } else {
        serve_static_file(client, path);
    }

    closesocket(client);
}

void server_start(int port) {
    WSADATA wsa;
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
        printf("[ERROR] WSAStartup failed: %d\n", WSAGetLastError());
        return;
    }

    SOCKET server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket == INVALID_SOCKET) {
        printf("[ERROR] Socket creation failed: %d\n", WSAGetLastError());
        WSACleanup();
        return;
    }

    int opt = 1;
    setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, (const char*)&opt, sizeof(opt));

    struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons((u_short)port);

    if (bind(server_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) == SOCKET_ERROR) {
        printf("[ERROR] Bind failed on port %d: %d\n", port, WSAGetLastError());
        closesocket(server_socket);
        WSACleanup();
        return;
    }

    if (listen(server_socket, 64) == SOCKET_ERROR) {
        printf("[ERROR] Listen failed: %d\n", WSAGetLastError());
        closesocket(server_socket);
        WSACleanup();
        return;
    }

    printf("==============================================================\n");
    printf("   VOLTQUEUE EV CHARGING TOKEN SYSTEM - ADVANCED C SERVER\n");
    printf("==============================================================\n");
    printf(">> Server listening on http://127.0.0.1:%d\n", port);
    printf(">> Active Features: Smart Recommendations, Dynamic Load Balancing,\n");
    printf("   Intelligent Marketplace & Token Queue Management\n");
    printf(">> Ready to handle browser requests. Press Ctrl+C to terminate.\n\n");
    fflush(stdout);

    while (1) {
        struct sockaddr_in client_addr;
        int client_len = sizeof(client_addr);
        SOCKET client_socket = accept(server_socket, (struct sockaddr*)&client_addr, &client_len);
        if (client_socket == INVALID_SOCKET) {
            continue;
        }
        handle_client(client_socket);
    }

    closesocket(server_socket);
    WSACleanup();
}
