#include "../include/cJSON.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

static cJSON *cJSON_New_Item(void) {
    cJSON* node = (cJSON*)calloc(1, sizeof(cJSON));
    return node;
}

void cJSON_Delete(cJSON *c) {
    cJSON *next;
    while (c != NULL) {
        next = c->next;
        if (c->child) cJSON_Delete(c->child);
        if (c->valuestring) free(c->valuestring);
        if (c->string) free(c->string);
        free(c);
        c = next;
    }
}

cJSON *cJSON_CreateObject(void) {
    cJSON *item = cJSON_New_Item();
    if (item) item->type = cJSON_Object;
    return item;
}

cJSON *cJSON_CreateArray(void) {
    cJSON *item = cJSON_New_Item();
    if (item) item->type = cJSON_Array;
    return item;
}

cJSON *cJSON_CreateString(const char *string) {
    cJSON *item = cJSON_New_Item();
    if (item) {
        item->type = cJSON_String;
        item->valuestring = string ? strdup(string) : NULL;
    }
    return item;
}

cJSON *cJSON_CreateNumber(double num) {
    cJSON *item = cJSON_New_Item();
    if (item) {
        item->type = cJSON_Number;
        item->valuedouble = num;
        item->valueint = (int)num;
    }
    return item;
}

cJSON *cJSON_CreateBool(int boolean) {
    cJSON *item = cJSON_New_Item();
    if (item) item->type = boolean ? cJSON_True : cJSON_False;
    return item;
}

cJSON *cJSON_CreateNull(void) {
    cJSON *item = cJSON_New_Item();
    if (item) item->type = cJSON_NULL;
    return item;
}

void cJSON_AddItemToArray(cJSON *array, cJSON *item) {
    if (!array || !item) return;
    if (!array->child) {
        array->child = item;
    } else {
        cJSON *c = array->child;
        while (c->next) c = c->next;
        c->next = item;
        item->prev = c;
    }
}

void cJSON_AddItemToObject(cJSON *object, const char *string, cJSON *item) {
    if (!object || !item) return;
    if (item->string) free(item->string);
    item->string = string ? strdup(string) : NULL;
    cJSON_AddItemToArray(object, item);
}

void cJSON_AddNullToObject(cJSON * const object, const char * const name) {
    cJSON_AddItemToObject(object, name, cJSON_CreateNull());
}
void cJSON_AddTrueToObject(cJSON * const object, const char * const name) {
    cJSON_AddItemToObject(object, name, cJSON_CreateBool(1));
}
void cJSON_AddFalseToObject(cJSON * const object, const char * const name) {
    cJSON_AddItemToObject(object, name, cJSON_CreateBool(0));
}
void cJSON_AddBoolToObject(cJSON * const object, const char * const name, const int boolean) {
    cJSON_AddItemToObject(object, name, cJSON_CreateBool(boolean));
}
void cJSON_AddNumberToObject(cJSON * const object, const char * const name, const double number) {
    cJSON_AddItemToObject(object, name, cJSON_CreateNumber(number));
}
void cJSON_AddStringToObject(cJSON * const object, const char * const name, const char * const string) {
    cJSON_AddItemToObject(object, name, cJSON_CreateString(string));
}

cJSON *cJSON_GetObjectItemCaseSensitive(const cJSON * const object, const char * const string) {
    if (!object || !string) return NULL;
    cJSON *c = object->child;
    while (c) {
        if (c->string && strcmp(c->string, string) == 0) return c;
        c = c->next;
    }
    return NULL;
}

int cJSON_IsString(const cJSON * const item) { return (item != NULL) && (item->type == cJSON_String); }
int cJSON_IsNumber(const cJSON * const item) { return (item != NULL) && (item->type == cJSON_Number); }
int cJSON_IsObject(const cJSON * const item) { return (item != NULL) && (item->type == cJSON_Object); }
int cJSON_IsArray(const cJSON * const item)  { return (item != NULL) && (item->type == cJSON_Array); }

typedef struct {
    char *buffer;
    size_t length;
    size_t capacity;
} PrintBuffer;

static void print_buffer_init(PrintBuffer *pb) {
    pb->capacity = 256;
    pb->length = 0;
    pb->buffer = (char*)malloc(pb->capacity);
    pb->buffer[0] = '\0';
}

static void print_buffer_append(PrintBuffer *pb, const char *str) {
    if (!str) return;
    size_t slen = strlen(str);
    while (pb->length + slen + 1 >= pb->capacity) {
        pb->capacity *= 2;
        pb->buffer = (char*)realloc(pb->buffer, pb->capacity);
    }
    memcpy(pb->buffer + pb->length, str, slen);
    pb->length += slen;
    pb->buffer[pb->length] = '\0';
}

static void print_value(const cJSON *item, PrintBuffer *pb) {
    if (!item) return;
    char temp[64];
    switch (item->type) {
        case cJSON_NULL:
            print_buffer_append(pb, "null");
            break;
        case cJSON_False:
            print_buffer_append(pb, "false");
            break;
        case cJSON_True:
            print_buffer_append(pb, "true");
            break;
        case cJSON_Number:
            if ((double)item->valueint == item->valuedouble) {
                snprintf(temp, sizeof(temp), "%d", item->valueint);
            } else {
                snprintf(temp, sizeof(temp), "%.2f", item->valuedouble);
            }
            print_buffer_append(pb, temp);
            break;
        case cJSON_String:
            print_buffer_append(pb, "\"");
            if (item->valuestring) {
                for (const char *p = item->valuestring; *p; p++) {
                    if (*p == '"' || *p == '\\') {
                        char esc[3] = {'\\', *p, '\0'};
                        print_buffer_append(pb, esc);
                    } else if (*p == '\n') {
                        print_buffer_append(pb, "\\n");
                    } else if (*p == '\r') {
                        print_buffer_append(pb, "\\r");
                    } else if (*p == '\t') {
                        print_buffer_append(pb, "\\t");
                    } else {
                        char ch[2] = {*p, '\0'};
                        print_buffer_append(pb, ch);
                    }
                }
            }
            print_buffer_append(pb, "\"");
            break;
        case cJSON_Array: {
            print_buffer_append(pb, "[");
            cJSON *c = item->child;
            while (c) {
                print_value(c, pb);
                if (c->next) print_buffer_append(pb, ",");
                c = c->next;
            }
            print_buffer_append(pb, "]");
            break;
        }
        case cJSON_Object: {
            print_buffer_append(pb, "{");
            cJSON *c = item->child;
            while (c) {
                print_buffer_append(pb, "\"");
                print_buffer_append(pb, c->string ? c->string : "");
                print_buffer_append(pb, "\":");
                print_value(c, pb);
                if (c->next) print_buffer_append(pb, ",");
                c = c->next;
            }
            print_buffer_append(pb, "}");
            break;
        }
    }
}

char *cJSON_PrintUnformatted(const cJSON *item) {
    PrintBuffer pb;
    print_buffer_init(&pb);
    print_value(item, &pb);
    return pb.buffer;
}

static const char *skip_whitespace(const char *p) {
    while (p && *p && (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r')) p++;
    return p;
}

static cJSON *parse_value(const char **p);

static char *parse_string_val(const char **p) {
    if (**p != '"') return NULL;
    (*p)++;
    const char *start = *p;
    while (**p && **p != '"') {
        if (**p == '\\' && *(*p + 1)) (*p)++;
        (*p)++;
    }
    size_t len = *p - start;
    char *str = (char*)malloc(len + 1);
    size_t out_idx = 0;
    for (size_t i = 0; i < len; i++) {
        if (start[i] == '\\' && i + 1 < len) {
            i++;
            if (start[i] == 'n') str[out_idx++] = '\n';
            else if (start[i] == 'r') str[out_idx++] = '\r';
            else if (start[i] == 't') str[out_idx++] = '\t';
            else str[out_idx++] = start[i];
        } else {
            str[out_idx++] = start[i];
        }
    }
    str[out_idx] = '\0';
    if (**p == '"') (*p)++;
    return str;
}

static cJSON *parse_object(const char **p) {
    cJSON *obj = cJSON_CreateObject();
    (*p)++;
    *p = skip_whitespace(*p);
    if (**p == '}') {
        (*p)++;
        return obj;
    }
    while (**p) {
        *p = skip_whitespace(*p);
        if (**p != '"') break;
        char *key = parse_string_val(p);
        *p = skip_whitespace(*p);
        if (**p == ':') (*p)++;
        cJSON *val = parse_value(p);
        if (val) {
            cJSON_AddItemToObject(obj, key, val);
        }
        if (key) free(key);
        *p = skip_whitespace(*p);
        if (**p == ',') {
            (*p)++;
        } else if (**p == '}') {
            (*p)++;
            break;
        }
    }
    return obj;
}

static cJSON *parse_array(const char **p) {
    cJSON *arr = cJSON_CreateArray();
    (*p)++;
    *p = skip_whitespace(*p);
    if (**p == ']') {
        (*p)++;
        return arr;
    }
    while (**p) {
        cJSON *val = parse_value(p);
        if (val) cJSON_AddItemToArray(arr, val);
        *p = skip_whitespace(*p);
        if (**p == ',') {
            (*p)++;
        } else if (**p == ']') {
            (*p)++;
            break;
        }
    }
    return arr;
}

static cJSON *parse_number(const char **p) {
    char *endptr;
    double val = strtod(*p, &endptr);
    *p = endptr;
    return cJSON_CreateNumber(val);
}

static cJSON *parse_value(const char **p) {
    *p = skip_whitespace(*p);
    if (!**p) return NULL;
    if (**p == '{') return parse_object(p);
    if (**p == '[') return parse_array(p);
    if (**p == '"') {
        char *s = parse_string_val(p);
        cJSON *item = cJSON_CreateString(s);
        if (s) free(s);
        return item;
    }
    if (strncmp(*p, "true", 4) == 0) {
        *p += 4;
        return cJSON_CreateBool(1);
    }
    if (strncmp(*p, "false", 5) == 0) {
        *p += 5;
        return cJSON_CreateBool(0);
    }
    if (strncmp(*p, "null", 4) == 0) {
        *p += 4;
        return cJSON_CreateNull();
    }
    if (**p == '-' || isdigit((unsigned char)**p)) {
        return parse_number(p);
    }
    return NULL;
}

cJSON *cJSON_Parse(const char *value) {
    if (!value) return NULL;
    const char *p = value;
    return parse_value(&p);
}
