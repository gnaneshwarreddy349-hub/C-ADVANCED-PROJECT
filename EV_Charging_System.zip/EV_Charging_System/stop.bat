@echo off
echo Stopping EV Charging Backend Server (ev_server.exe)...
taskkill /F /IM ev_server.exe >nul 2>&1
if %ERRORLEVEL% equ 0 (
    echo Server stopped successfully.
) else (
    echo No active ev_server.exe process found.
)
