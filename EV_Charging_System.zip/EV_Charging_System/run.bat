@echo off
setlocal
cd /d "%~dp0"

set PORT=8080
set URL=http://127.0.0.1:%PORT%

:: Configure GCC environment
set PATH=C:\msys64\ucrt64\bin;C:\MinGW\bin;%PATH%

echo ============================================================
echo  VoltQueue EV Charging System - Starting...
echo ============================================================

:: 1. Kill any existing instance to free the port
taskkill /F /IM ev_server.exe >nul 2>&1
ping -n 2 127.0.0.1 >nul

:: 2. Compile backend
echo [STEP 1/3] Compiling C backend...
call build.bat
if %ERRORLEVEL% neq 0 (
    echo.
    echo [ERROR] Compilation failed. Fix errors above and try again.
    pause
    exit /b 1
)

echo [STEP 2/3] Starting C HTTP server...

:: 3. Spawn a dedicated, independent server console window that stays open
start "VoltQueue C Backend Server [DO NOT CLOSE]" cmd /k "cd /d "%~dp0" && backend\bin\ev_server.exe %PORT%"

:: 4. Wait for socket to initialize
ping -n 3 127.0.0.1 >nul

echo [STEP 3/3] Opening browser at %URL%

:: 5. Open in Chrome or default browser
start "" "%URL%"

echo.
echo [OK] VoltQueue is running at %URL%
echo [OK] Keep the "VoltQueue C Backend Server" window open!
echo.
