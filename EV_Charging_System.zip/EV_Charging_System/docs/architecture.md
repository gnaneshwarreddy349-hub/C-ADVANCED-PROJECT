# VoltQueue System Architecture & Engineering Specification

## 1. Executive Summary
VoltQueue is a full-stack, enterprise-grade Electric Vehicle (EV) Charging Token & Slot Management System engineered in **Advanced C (C99/C11)**. Designed specifically for academic capstone presentation and production-like reliability on Windows, the system operates as a zero-dependency high-concurrency native server.

---

## 2. System Architecture Layers

```
+-------------------------------------------------------------+
|             PRESENTATION LAYER (HTML5, CSS3, JS)            |
|  - index.html (Live Station Availability & Public Portal)    |
|  - login.html & register.html (Driver/Admin Auth)            |
|  - dashboard.html (Driver Self-Service & Token Pass)         |
|  - admin.html (Station Operations & Live Queue Controller)   |
+-------------------------------------------------------------+
                              |
                     HTTP / JSON Protocol
                   (Winsock2 TCP Port 8080)
                              |
+-------------------------------------------------------------+
|               C EMBEDDED HTTP WEB ENGINE                    |
|  - server.c: Request Router, Header Parser, Static File Host|
|  - cJSON.c: Zero-Dependency JSON Parser & Serializer        |
+-------------------------------------------------------------+
                              |
+-------------------------------------------------------------+
|            CORE BUSINESS LOGIC & DATA STRUCTURES            |
|  - core.c: FIFO Queue Engine, Estimated Wait Calculator     |
|  - sha256.c: Cryptographic Password Hashing (Salted SHA256) |
|  - types.h: Enums, Bit-packed Structures, Data Contracts    |
+-------------------------------------------------------------+
                              |
+-------------------------------------------------------------+
|            PERSISTENT BINARY STORAGE SUBSYSTEM              |
|  - storage.c: Atomic Safe File IO (.tmp -> rename pattern)  |
|  - data/users.dat, data/stations.dat, data/bookings.dat     |
+-------------------------------------------------------------+
```

---

## 3. Advanced C Concepts Demonstrated
1. **Dynamic Memory Allocation & Safety**: Strict buffer checking using `calloc`, `malloc`, and `free` across JSON tree construction.
2. **Atomic Binary Persistence**: To prevent corruption upon crash or sudden power loss, records are written to `.tmp` files and atomically replaced via `rename()`.
3. **FIFO Queue & Waiting Time Algorithm**:
   - Positions assigned sequentially to unallocated slots.
   - Batch estimation based on charging point count:
     $$\text{EstWait} = \left(\left\lfloor \frac{\text{QueuePosition} - 1}{\text{PortCount}} \right\rfloor + 1\right) \times \text{AvgDuration}$$
4. **Role-Based Access Control (RBAC)**: Enforced in C request handlers. Non-admin tokens receive HTTP 403 Forbidden on administrative endpoints.
