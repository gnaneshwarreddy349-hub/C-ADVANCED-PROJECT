# Faculty Demonstration Script (5-10 Minutes)

### Step 1: Launch Application
1. Open the project folder in VS Code or File Explorer:
   `C:\Users\gnane\OneDrive\EV_Charging_System`
2. Double click or execute in PowerShell:
   ```powershell
   .\run.bat
   ```
3. The script verifies GCC, compiles all C files, starts the server, and automatically opens Google Chrome to `http://127.0.0.1:8080`.

### Step 2: Live Station Availability
- Show the home page featuring 3 default stations with real-time port status loaded from binary storage.

### Step 3: Administrator Portal
- Sign in with `Agreddy` / `Agreddy@123`.
- Show live telemetry: Total Users, Total Stations, Revenue, Active Sessions.
- Demonstrate deploying a new station or taking a charging point offline.

### Step 4: Driver Workflow
- Register a new driver account (e.g., `driver1` / `Driver@123`).
- Add an EV (e.g. `TS09EV9999` - Tata Nexon EV).
- Book a charging slot: observe instant digital token generation (`EV-TK-XXXX-XX`).
- Simulate plugging in and starting charging, then completing charging and verifying the calculated tariff.

### Step 5: Persistence Demonstration
- Stop the server with `.\stop.bat`.
- Relaunch with `.\run.bat`.
- Refresh browser: show that all users, registered vehicles, stations, and booking histories remained intact.
