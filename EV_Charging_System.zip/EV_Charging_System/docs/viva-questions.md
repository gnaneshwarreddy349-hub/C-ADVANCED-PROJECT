# VoltQueue - Academic Viva-Voce Questions & Comprehensive Answers

### Q1: Why did you choose C rather than Node.js or Python for the backend?
**Answer:** C provides direct memory control, deterministic execution, and minimal resource footprints without requiring heavy runtime interpreters. It demonstrates core computer science competencies—pointers, memory allocation, structures, and OS-level socket programming.

### Q2: How does the system achieve persistent storage without an SQL engine?
**Answer:** We implemented custom binary record serialization using standard C file operations (`fopen`, `fwrite`, `fread`). Updates use atomic writes: records are written to a temporary `.tmp` file and swapped via `rename()`.

### Q3: How is password security maintained in pure C?
**Answer:** Passwords are never stored in plaintext. We implemented a complete cryptographic SHA-256 hashing engine combined with a 16-character pseudo-random salt. Authentication re-hashes the input password with the stored salt and compares the hash strings.

### Q4: How does the FIFO Queue mechanism work?
**Answer:** When all station ports are occupied, incoming booking requests are placed into a FIFO queue. Queue positions are strictly monotonic. Once an active charging session completes or is cancelled, `queue_recalculate_station()` dynamically shifts waiting drivers forward and assigns the first available port.

### Q5: How is waiting time estimated?
**Answer:** Waiting time is calculated using the formula:
`((queue_position - 1) / total_ports + 1) * avg_duration_mins`. This gives realistic scheduling based on parallel charging bays.

### Q6: How does the C server handle static web assets (HTML/CSS/JS)?
**Answer:** The C HTTP server inspects file extensions (`.html`, `.css`, `.js`), sets appropriate MIME headers (`text/html`, `text/css`, `application/javascript`), and streams the file binary via `send()` over Winsock.
