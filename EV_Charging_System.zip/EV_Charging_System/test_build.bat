@echo off
set PATH=C:\\msys64\\ucrt64\\bin;%PATH%
cd /d C:\\Users\\gnane\\OneDrive\\EV_Charging_System\\backend
gcc src/sha256.c src/storage.c src/core.c src/cJSON.c src/server.c src/main.c -lws2_32 -o bin/ev_server.exe
echo BUILD_EXIT_%ERRORLEVEL%
