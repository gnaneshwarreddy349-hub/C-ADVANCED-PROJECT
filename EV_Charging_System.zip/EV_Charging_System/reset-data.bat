@echo off
echo ==========================================================
echo RESETTING DEMONSTRATION DATA (PERSISTENT BINARY RE-INIT)
echo ==========================================================
if exist "data\users.dat" del /F /Q "data\users.dat"
if exist "data\vehicles.dat" del /F /Q "data\vehicles.dat"
if exist "data\stations.dat" del /F /Q "data\stations.dat"
if exist "data\bookings.dat" del /F /Q "data\bookings.dat"
if exist "data\*.tmp" del /F /Q "data\*.tmp"
echo [OK] All previous data files cleared. Default records will re-seed on startup.
