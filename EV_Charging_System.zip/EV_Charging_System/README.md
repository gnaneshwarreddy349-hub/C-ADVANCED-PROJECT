# VoltQueue - EV Charging Token Management System
> **B.Tech Computer Science Capstone Project**  
> Advanced C Backend | Winsock2 HTTP Server | Vanilla HTML5/CSS3/JS | GCC/MinGW-w64 | Windows 10/11

---

## One-Click Quickstart
Execute in PowerShell or Command Prompt:
```powershell
.\run.bat
```
This compiles the C source code, launches the background HTTP engine, and opens the application in Google Chrome at `http://127.0.0.1:8080`.

## Admin Credentials
- **Username:** `Agreddy`
- **Password:** `Agreddy@123`
- **Mobile:** `7207551850`

## Batch Utilities
- `run.bat` — Compile backend, launch server, and open Chrome.
- `stop.bat` — Cleanly terminate `ev_server.exe`.
- `build.bat` — Compile C backend with GCC.
- `reset-data.bat` — Reset binary database to initial demo state.
