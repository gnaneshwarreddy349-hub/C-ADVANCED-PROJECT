const API_BASE = '/api';

const api = {
    getToken() {
        return localStorage.getItem('ev_token');
    },

    setToken(token) {
        localStorage.setItem('ev_token', token);
    },

    removeToken() {
        localStorage.removeItem('ev_token');
        localStorage.removeItem('ev_user');
    },

    getUser() {
        try {
            return JSON.parse(localStorage.getItem('ev_user'));
        } catch (e) {
            return null;
        }
    },

    setUser(user) {
        localStorage.setItem('ev_user', JSON.stringify(user));
    },

    async request(endpoint, options = {}) {
        const headers = {
            'Content-Type': 'application/json',
            ...(options.headers || {})
        };

        const token = this.getToken();
        if (token) {
            headers['Authorization'] = 'Bearer ' + token;
        }

        const config = {
            ...options,
            headers
        };

        const separator = endpoint.includes('?') ? '&' : '?';
        const urlWithCacheBuster = API_BASE + endpoint + separator + '_t=' + Date.now();

        try {
            const res = await fetch(urlWithCacheBuster, config);
            const data = await res.json();
            if (!res.ok) {
                throw new Error(data.error || 'Request failed');
            }
            return data;
        } catch (err) {
            throw err;
        }
    },

    // Auth
    login(username, password) {
        return this.request('/auth/login', {
            method: 'POST',
            body: JSON.stringify({ username, password })
        });
    },

    register(username, password, full_name, mobile) {
        return this.request('/auth/register', {
            method: 'POST',
            body: JSON.stringify({ username, password, full_name, mobile })
        });
    },

    logout() {
        return this.request('/auth/logout', { method: 'POST' });
    },

    getMe() {
        return this.request('/auth/me');
    },

    // Stations
    getStations() {
        return this.request('/stations');
    },

    addStation(station) {
        return this.request('/stations', {
            method: 'POST',
            body: JSON.stringify(station)
        });
    },

    updateStation(station) {
        return this.request('/stations/update', {
            method: 'POST',
            body: JSON.stringify(station)
        });
    },

    // Vehicles
    getVehicles() {
        return this.request('/vehicles');
    },

    addVehicle(vehicle) {
        return this.request('/vehicles', {
            method: 'POST',
            body: JSON.stringify(vehicle)
        });
    },

    deleteVehicle(id) {
        return this.request('/vehicles/delete', {
            method: 'POST',
            body: JSON.stringify({ id })
        });
    },

    // Bookings
    createBooking(booking) {
        return this.request('/bookings', {
            method: 'POST',
            body: JSON.stringify(booking)
        });
    },

    getBookings() {
        return this.request('/bookings');
    },

    cancelBooking(id) {
        return this.request('/bookings/cancel', {
            method: 'POST',
            body: JSON.stringify({ id })
        });
    },

    startCharging(id) {
        return this.request('/bookings/start-charging', {
            method: 'POST',
            body: JSON.stringify({ id })
        });
    },

    completeCharging(id, energy_kwh) {
        return this.request('/bookings/complete-charging', {
            method: 'POST',
            body: JSON.stringify({ id, energy_kwh })
        });
    },

    // FEATURE 1: Smart Charging Recommendations
    getRecommendations(vehicle_id, latitude, longitude) {
        return this.request('/recommendations', {
            method: 'POST',
            body: JSON.stringify({ vehicle_id, latitude, longitude })
        });
    },

    // Admin Operational Statistics (Preserved Admin Functions)
    getStats() {
        return this.request('/admin/stats');
    }
};
