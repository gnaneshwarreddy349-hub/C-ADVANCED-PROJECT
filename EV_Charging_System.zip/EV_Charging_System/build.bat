@echo off
setlocal
cd /d "%~dp0backend"
set PATH=C:\msys64\ucrt64\bin;C:\MinGW\bin;%PATH%
echo [BUILD] Compiling VoltQueue C backend...
gcc src/sha256.c src/storage.c src/core.c src/cJSON.c src/server.c src/main.c -lws2_32 -lm -o bin/ev_server.exe -Wall -Wno-unused-result
if %ERRORLEVEL% equ 0 (
    echo [BUILD] SUCCESS - ev_server.exe ready
) else (
    echo [BUILD] FAILED - check compiler errors above
)
exit /b %ERRORLEVEL%
