Set WshShell = CreateObject("WScript.Shell")
WshShell.CurrentDirectory = "C:\Users\gnane\OneDrive\EV_Charging_System"
WshShell.Run "backend\bin\ev_server.exe 8080", 0, False
